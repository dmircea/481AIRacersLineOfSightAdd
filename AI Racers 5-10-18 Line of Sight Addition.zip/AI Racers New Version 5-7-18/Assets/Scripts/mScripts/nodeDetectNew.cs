﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//  Originally made by chris

public class nodeDetectNew : MonoBehaviour {
    public GameObject driveObj;
    public GameObject ObjectWithPath;
    drivingManager drive;



	// Use this for initialization
	void Start ()
    {
        drive = driveObj.GetComponent<drivingManager>();	
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    public void OnTriggerEnter2D(Collider2D collision)
    {
        print("processing collision");
        if (collision.gameObject.tag == "LineOfSightNode" && ObjectWithPath.GetComponent<GraphImplement>().getPath().Contains(collision.gameObject))//we've hit a node, let driving AI know it's time to move to the next one
        {
            
            drive.nextNode();
            if(collision.gameObject == ObjectWithPath.GetComponent<GraphImplement>().root)
            {
                ObjectWithPath.GetComponent<GraphImplement>().getClosedSpace().Clear();
            }
        }
        
    }

}
