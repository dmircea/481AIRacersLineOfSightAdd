﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class nodeDetect : MonoBehaviour
{
    public GameObject driveObj;
    driving drive;
    [SerializeField]
    public List<GameObject> waypoints;
    [SerializeField]
    public List<GameObject> starpoints;
    public List<GameObject> open;
    public List<GameObject> closed;
    public List<GameObject> other;
    public List<GameObject> goal;
    public GameObject set;
    public int j;

    // Use this for initialization
    void Start()
    {
        
        drive = driveObj.GetComponent<driving>();
        Astar();
        for (int i = 0; i < waypoints.Count; i++)
        {
            closed.Insert(i, waypoints[i]);
        }
        closed.RemoveAt(0);
        closed.RemoveAt(0);
        j = 0;
    }

    // Update is called once per frame
    void Update()
    {
        drive = driveObj.GetComponent<driving>();

    }
    public void OnTriggerEnter2D(Collider2D collision)
    {
        //print("processing collision");
        if (collision.gameObject.tag == "node")//we've hit a node, let driving AI know it's time to move to the next one
        {
            //Opencheck();


            // drive.NextTarget();
            //check to ensure that the node we collided with is our target
            if(drive.nextTarget == null)
            {
                drive.nextTarget = starpoints[1];
            }
            if (collision.gameObject != drive.destination)
            {
               // drive.car.Turn(1);
                return;
            }
            
            Opencheck();
            drive.nextNode();
            //GetNode(open,closed,drive.destination)
        }


    }
    public GameObject GetNode()
    {
        //print("Enter getnode");
        set = closed[0];
        closed.RemoveAt(0);
        /*while (cost == 0)
        {
            if (open.Count != 0)
            {
                goal.Add(open[k]);
                dum = Vector2.Distance(goal[k].transform.position, drive.destination.transform.position);
                print(dum+ " of " + goal[k].name);
                Vector3 toTarget = ( drive.destination.transform.position- goal[k].transform.position).normalized;
                if (Vector3.Dot(toTarget, drive.destination.transform.forward) < 0)
                {
                    closed.Add(open[k]);
                    j++;
                    Destroy(open[k]);
                    open.RemoveAt(k);
                }
                else if (cost < Vector2.Distance(drive.nextTarget.transform.position, goal[k].transform.position))
                {
                    cost = Vector2.Distance(drive.nextTarget.transform.position, goal[k].transform.position);
                   
                    set = goal[k];
                }

            }
            k++;

        }*/
        //print("going to " + set.name);
        return set;
    }
    public void Opencheck()
    {
        if (closed.Count == 0)
        {
            for (int i = 0; i < goal.Count-1; i++)
            {
                closed.Insert(i,goal[i]);
            }
            //closed = new GameObject[waypoints.Count];

        }
    }
    public void Astar()
    {
        int j = 0;
        float f, g, h;
        GameObject check1,check2;
        for(int i = 0;i < starpoints.Count;i++)
        {
            open.Insert(i, starpoints[i]);
        }
        //f(n) = g(n) + h(n)
        //g(n) = total dist from start node[0] to where current node
        //h(n)= dist from current node to last node[]
        goal.Insert(0, starpoints[0]);//start node of course car needs to start somewhere
        j++;
        open.RemoveAt(0);
        while(open.Count > 0)
        {
            
            check1 = open[0];
            check2 = open[1];
            g = Vector2.Distance(goal[0].transform.position,check1.transform.position);
            h = Vector2.Distance(check1.transform.position, starpoints[starpoints.Count - 1].transform.position);
            f = g + h;

            g = Vector2.Distance(goal[0].transform.position, check2.transform.position);
            h = Vector2.Distance(check2.transform.position, starpoints[starpoints.Count - 1].transform.position);
            if(f> (g+h)) //use check2
            {
                //f = g + h;
                goal.Insert(j, check2);
                open.RemoveAt(0);
                open.RemoveAt(0);
                j++;
            }
            else //use check1
            {
                goal.Insert(j, check1);
                open.RemoveAt(0);
                j++;

            }
            f = 0; g = 0; h =0;
            /*if (open.Count == 2)
            {
                goal.Insert(j, open[0]); //put last node in here
                j++;
                open.RemoveAt(0);
                goal.Insert(j, open[0]);
                open.RemoveAt(0);
                for (int i = 0; i < goal.Count; i++)
                {
                    waypoints.Insert(i, goal[i]); //found best path to use for car
                }
                break;
            }*/
            //Vector3 toTarget = (drive.destination.transform.position - goal[k].transform.position).normalized;
            /*if (Vector3.Dot(toTarget, drive.destination.transform.forward) < 0)
            {
               closed.Add(open[k]);
               j++;
               Destroy(open[k]);
               open.RemoveAt(k);
            }
            else if (cost < Vector2.Distance(drive.nextTarget.transform.position, goal[k].transform.position))
            {
               cost = Vector2.Distance(drive.nextTarget.transform.position, goal[k].transform.position);
               set = goal[k];
            }*/




        }
        //waypoints.Insert(0, starpoints[1]);
        for (int i = 0; i < goal.Count; i++)
        {
            waypoints.Insert(i, goal[i]); //found best path to use for car
        }

    }

}
