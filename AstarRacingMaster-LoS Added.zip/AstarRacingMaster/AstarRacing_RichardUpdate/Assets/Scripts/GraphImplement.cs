﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GraphImplement : MonoBehaviour {

    public GameObject track;

    public GameObject car;

    public GameObject root;
    public GameObject dest;

    //public List<GameObject> startingLine = new List<GameObject>();
    public List<GameObject> finishLine = new List<GameObject>();
    public List<GameObject> waypoints = new List<GameObject>();

    private int sightLevel = 0;
    [SerializeField]
    private List<GameObject> path = new List<GameObject>();
    [SerializeField]
    private List<GameObject> closedSet = new List<GameObject>();

    //------------------------------------NOTE-------------------------------------------
    //  Make sure that the dest variable is a non-occupied node between starting line and finish line
    //  You have to manually drag the destination node to the dest variable in Unity
    //-----------------------------------------------------------------------------------

    void Start () {
        //  Make the root be the currently occupied Node
        
        //root = track.GetComponent<GraphManager>().occupiedNodes[0];

        //  Start IEnum using root and dest (dest is manually placed)
        StartCoroutine(lineOfSightStarAlg(root,dest));
	}

    public void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        for (int i = 0; i < waypoints.Count; ++i)
        {
            if (i == waypoints.Count -1)
            {
                Gizmos.DrawLine(waypoints[i].transform.position, waypoints[0].transform.position);
            }
            else
            {
                Gizmos.DrawLine(waypoints[i].transform.position, waypoints[i + 1].transform.position);
            }
        }
    }

    //  NOTE: Original algorithm for now, will be changed to actual one later
    IEnumerator lineOfSightStarAlg(GameObject start,GameObject goal,int farSight = 10)
    {

        List<GameObject> openSet = new List<GameObject>();
        openSet.Insert(0,start);
        GameObject current;

        //  This will be used for storing the four choices
        List<GameObject> choiceList = new List<GameObject>();


        
        //  Finding cost for node from start to that node
        

        while(openSet.Count != 0)
        {
            current = openSet[0];

            //  Check if current is a waypoint
            //  If so, remove it then add it (changes places from front to back)
            if (waypoints.Contains(current))
            {
                GameObject changingWaypoint = waypoints[0];
                waypoints.Remove(changingWaypoint);
                waypoints.Add(changingWaypoint);
                //closedSet.RemoveRange(0, 2);
            }

            if (current == dest)
            {
                closedSet.RemoveRange(0, closedSet.Count);
            }

            //  Check for neighbor nodes from current
            foreach (GameObject neigborNodes in current.GetComponent<Neighbors>().GetEnumerable())
            {

                if (neigborNodes != null && !closedSet.Contains(neigborNodes) /*&& !startingLine.Contains(neigborNodes)*/)
                {
                    choiceList.Add(neigborNodes);
                }
                
            }

            //  Check distance to next waypoint from each node.
            float distance = 10000F;
            GameObject idealNode = null;
            foreach (GameObject node in choiceList)
            {
                if (Vector2.Distance(node.transform.position,waypoints[0].transform.position) < distance)
                {
                    idealNode = node;
                    distance = Vector2.Distance(node.transform.position, waypoints[0].transform.position);
                }
            }

            path.Add(idealNode);
            openSet.Add(idealNode);

            if (path.Count == 10)
            {
                yield return new WaitUntil(() => path.Count < 10);
            }

            closedSet.Add(current);
            openSet.Remove(current);
            choiceList.Clear();

            

        }

        yield break;

    }

    public List<GameObject> getPath()
    {
        return path;
    }
    public List<GameObject> getClosedSpace()
    {
        return closedSet;
    }

    public void clearSpace(List<GameObject> someList)
    {
        someList.Clear();
    }

    // Update is called once per frame
    void Update () {
        if (path.Count > 2 && path.Count <= 10)
        {
            if (car.GetComponentInChildren<drivingManager>().destination == car.GetComponentInChildren<drivingManager>().nextTarget)
            {
                path.RemoveAt(0);
                print("A node has been removed!");
            }
            car.GetComponentInChildren<drivingManager>().destination = path[0];
            car.GetComponentInChildren<drivingManager>().nextTarget = path[1];
        }
    }
}
