﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Neighbors : MonoBehaviour {

    public GameObject up;
    public GameObject down;
    public GameObject right;
    public GameObject left;

    public bool isStart = false;

    [SerializeField]
    private bool occupied = false;
    private GameObject tempCar;

	// Use this for initialization
	void Start () {
		
	}
	
    public IEnumerable GetEnumerable()
    {
        yield return up;
        yield return down;
        yield return right;
        yield return left;
    }

    public void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Car")
        {
            occupied = true;
            tempCar = other.gameObject;
            //  The line below will find the occupied Nodes list in parent and add itself to it.
            this.gameObject.GetComponentInParent<GraphManager>().occupiedNodes.Add(this.gameObject);
        }
    }

    public void OnTriggerExit2D(Collider2D other)
    {
        if(other.tag == "Car")
        {
            occupied = false;
            tempCar = null;
            //  The line below will find the occupied Nodes list in parent and remove itself from it.
            this.gameObject.GetComponentInParent<GraphManager>().occupiedNodes.Remove(this.gameObject);
        }
    }

    // Update is called once per frame
    void Update () {
		
	}
}
