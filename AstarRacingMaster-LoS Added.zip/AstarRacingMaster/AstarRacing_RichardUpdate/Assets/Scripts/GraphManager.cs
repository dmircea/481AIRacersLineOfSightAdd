﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GraphManager : MonoBehaviour {

    public bool checkToRemap = false;

    public List<Neighbors> childrenNeighbors;
    public List<Transform> childrenTransform;

    public List<GameObject> occupiedNodes;

	// Use this for initialization

        //--------------------------------NOTE------------------------------------------------
        //  Place Nodes in a gridlike pattern with a distance of 1.5 between each node
        //--------------------------------NOTE------------------------------------------------
	void Start () {
		
	}

    private void cleanUpNodeConnections()
    {
        for (int i = 0; i < childrenNeighbors.Count; ++i)
        {
            childrenNeighbors[i].up = null;
            childrenNeighbors[i].down = null;
            childrenNeighbors[i].right = null;
            childrenNeighbors[i].left = null;
        }
    }

    // Connect nodes in a distance of 1.5
    // Only uses the horizontal and vertical axi
    private void connectNodesByDistance(List<Neighbors> neighbors,List<Transform> transform)
    {
        for (int i = 0; i < neighbors.Count; ++i)
        {
            
            for (int j = 0; j < transform.Count; ++j)
            {
                Vector2 current = neighbors[i].gameObject.transform.position;
                Vector2 other = transform[j].position;

                current = current * 10;
                other = other * 10;

                current = Vector2Int.RoundToInt(current);
                other = Vector2Int.RoundToInt(other);

                current = current / 10;
                other = other / 10;


                if (i < 2 && j < 2)//       DEBUG
                {
                    print("Here is current:" + current);
                    print("Here is other:" + other);
                }

                //  Check for upper linking "up"
                if (Mathf.Approximately(current.y, other.y - 1.5f) && Mathf.Approximately(current.x, other.x))
                {
                    neighbors[i].up = transform[j].gameObject;
                    print("Hit! " + current + " with " + other + " as " + "current.up = other" );
                }
                //  Check for lower linking "down"
                if (Mathf.Approximately(current.y, other.y + 1.5f) && Mathf.Approximately(current.x, other.x))
                {
                    neighbors[i].down = transform[j].gameObject;
                    print("Hit!" + current + " with " + other + " as " + "current.down = other");
                }
                //  Check for right-side linking "right"
                if (Mathf.Approximately(current.y, other.y) && Mathf.Approximately(current.x, other.x - 1.5f))
                {
                    neighbors[i].right = transform[j].gameObject;
                    print("Hit!" + current + " with " + other + " as " + "current.right = other");
                }
                //  Check for left-side linking "left"
                if (Mathf.Approximately(current.y, other.y) && Mathf.Approximately(current.x, other.x + 1.5f))
                {
                    neighbors[i].left = transform[j].gameObject;
                    print("Hit!" + current + " with " + other + " as " + "current.left = other");
                }
            }
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.white;
        /*List<Neighbors>*/ childrenNeighbors = new List<Neighbors>(GetComponentsInChildren<Neighbors>());
        /*List<Transform>*/ childrenTransform = new List<Transform>(GetComponentsInChildren<Transform>());
        childrenTransform.Remove(this.transform);

        if (checkToRemap)
        {
            cleanUpNodeConnections(); 
            connectNodesByDistance(childrenNeighbors, childrenTransform);
            checkToRemap = false;
        }

        for (int i = 0; i < childrenNeighbors.Count; ++i)
        {
            if(childrenNeighbors[i].up != null)
            {
                Gizmos.DrawLine(childrenTransform[i].position, childrenNeighbors[i].up.transform.position);
            }
            if (childrenNeighbors[i].down != null)
            {
                Gizmos.DrawLine(childrenTransform[i].position, childrenNeighbors[i].down.transform.position);
            }
            if (childrenNeighbors[i].left != null)
            {
                Gizmos.DrawLine(childrenTransform[i].position, childrenNeighbors[i].left.transform.position);
            }
            if (childrenNeighbors[i].right != null)
            {
                Gizmos.DrawLine(childrenTransform[i].position, childrenNeighbors[i].right.transform.position);
            }
        }

    }

    // Update is called once per frame
    void Update () {
		
	}
}
